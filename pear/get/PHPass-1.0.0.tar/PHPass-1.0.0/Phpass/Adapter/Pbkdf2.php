<?php
/**
 * Portable PHP password hashing framework.
 *
 * @package PHPass
 * @subpackage Adapters
 * @category Cryptography
 * @author Solar Designer <solar at openwall.com>
 * @author Ryan Chouinard <rchouinard at gmail.com>
 * @license http://www.opensource.org/licenses/mit-license.html MIT License
 * @link http://www.openwall.com/phpass/ Original phpass project page.
 * @link https://github.com/rchouinard/phpass PHPass project at GitHub.
 */

/**
 * @namespace
 */
namespace Phpass\Adapter;
use Phpass\Exception\InvalidArgumentException,
    Phpass\Exception\RuntimeException;

/**
 * @see Phpass\Adapter\Base
 */
require_once 'Phpass/Adapter/Base.php';

/**
 * @see Phpass\Exception\InvalidArgumentException
 */
require_once 'Phpass/Exception/InvalidArgumentException.php';

/**
 * @see Phpass\Exception\RuntimeException
 */
require_once 'Phpass/Exception/RuntimeException.php';

/**
 * Portable PHP password hashing framework.
 *
 * @package PHPass
 * @subpackage Adapters
 * @category Cryptography
 * @author Solar Designer <solar at openwall.com>
 * @author Ryan Chouinard <rchouinard at gmail.com>
 * @license http://www.opensource.org/licenses/mit-license.html MIT License
 * @link http://www.openwall.com/phpass/ Original phpass project page.
 * @link https://github.com/rchouinard/phpass PHPass project at GitHub.
 */
class Pbkdf2 extends Base
{

    /**
     * @var string
     */
    protected $_algo;

    /**
     * @param array $options
     * @return void
     */
    public function __construct(Array $options = array ())
    {
        parent::__construct($options);

        $this->_algo = $this->_algo ?: 'sha256';
        $this->_iterationCountLog2 = $this->_iterationCountLog2 ?: 12;
    }

    /**
     * (non-PHPdoc)
     * @see Phpass\Adapter\Base::crypt()
     */
    public function crypt($password, $setting = null)
    {
        if (!$setting) {
            $setting = $this->genSalt();
        }

        // Return blowfish error string *0 or *1 on failure
        // Portable adapter does this, so we do it here to remain consistent
        $output = '*0';
        if (substr($setting, 0, 2) == $output) {
            $output = '*1';
        }

        if (substr($setting, 0, 6) != '$p5v2$') {
            return $output;
        }

        $countLog2 = $countLog2 = strpos($this->_itoa64, $setting[6]);
        if ($countLog2 < 0 || $countLog2 > 30) {
            return $output;
        }
        $count = 1 << $countLog2;

        $salt = substr($setting, 7, 8);
        if (strlen($salt) != 8) {
            return $output;
        }

        $hash = $this->_pbkdf2($password, $salt, $count, 24, $this->_algo);

        $output = substr($setting, 0, 16);
        $output .= $this->_encode64($hash, 24);

        return $output;
    }

    /**
     * (non-PHPdoc)
     * @see Phpass\Adapter::genSalt()
     */
    public function genSalt($input = null)
    {
        if (!$input) {
            $input = $this->_getRandomBytes(6);
        }

        // PKCS #5, version 2
        // Python implementation uses $p5k2$, but we're not using a compatible
        // string. https://www.dlitz.net/software/python-pbkdf2/
        $output = '$p5v2$';

        // Iteration count between 1 and 1,073,741,824
        $output .= $this->_itoa64[min(max($this->_iterationCountLog2, 0), 30)];

        // 8-byte (64-bit) salt value, as recommended by the standard
        $output .= $this->_encode64($input, 6);

        // $p5v2$CSSSSSSSS$
        return $output . '$';
    }

    /**
     * (non-PHPdoc)
     * @see Phpass\Adapter::isSupported()
     */
    public function isSupported()
    {
        return extension_loaded('hash');
    }

    /**
     * (non-PHPdoc)
     * @see Phpass\Adapter::isValid()
     */
    public function isValid($hash)
    {
        $isValid = true;
        if (substr($hash, 0, 6) != '$p5v2$' || strlen($hash) != 48) {
            $isValid = false;
        }

        return $isValid;
    }

    /**
     * Internal implementation of PKCS #5 v2.0
     *
     * This implementation passes tests using vectors given in RFC 6070 s.2,
     * PBKDF2 HMAC-SHA1 Test Vectors. Vectors given for PBKDF2 HMAC-SHA2 at
     * {@link http://stackoverflow.com/questions/5130513} also pass.
     *
     * @param string $password
     * @param string $salt
     * @param integer $iterationCount
     * @param integer $keyLength
     * @return string
     */
    protected function _pbkdf2($password, $salt, $iterationCount = 1000, $keyLength = 20, $algo = 'sha1')
    {
        $hashLength = strlen(hash($algo, null, true));
        $keyBlocks = ceil($keyLength / $hashLength);
        $derivedKey = '';

        for ($block = 1; $block <= $keyBlocks; ++$block) {
            $iteratedBlock = $currentBlock = hash_hmac($algo, $salt . pack('N', $block), $password, true);
            for ($iteration = 1; $iteration < $iterationCount; ++$iteration) {
                $iteratedBlock ^= $currentBlock = hash_hmac($algo, $currentBlock, $password, true);
            }

            $derivedKey .= $iteratedBlock;
        }

        return substr($derivedKey, 0, $keyLength);
    }

}